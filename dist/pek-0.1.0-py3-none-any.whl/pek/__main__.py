from .version import __version__

if __name__ == "__main__":
    print(f"pek v{__version__}")
